package service;

import org.assertj.core.util.BigDecimalComparator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CartServicePTest {

    private final CartService cartService = new CartService();

    @ParameterizedTest
    @MethodSource("basketArgs")
    public void shouldCalculateTwoForOneDeal(List<String> fruits, BigDecimal expectedValue) {
        assertThat(cartService.sumUpCartValue(fruits))
                .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
                .isEqualByComparingTo(expectedValue);
    }

    private static Stream<Arguments> basketArgs() {
        return Stream.of(
                Arguments.of(List.of("Apple","Apple","Apple"), BigDecimal.valueOf(1.05)),
                Arguments.of(List.of("Banana","Banana","Banana"), BigDecimal.valueOf(0.60)),
                Arguments.of(List.of("Melon","Melon","Melon","Melon"), BigDecimal.valueOf(1.00)),
                Arguments.of(List.of("Lime","Lime","Lime","Lime","Lime","Lime"), BigDecimal.valueOf(0.60)),
                Arguments.of(List.of("Apple","Apple","Apple","Banana","Banana","Banana","Melon","Melon","Melon","Melon","Lime","Lime","Lime","Lime","Lime","Lime"), BigDecimal.valueOf(3.25)),
                Arguments.of(List.of("Lime","Lime","Lime","Lime","Lime","Lime"), BigDecimal.valueOf(0.60))
        );
    }

    @Test
    public void shouldThrowAnExceptionIfNotRealFruit() {
        assertThrows(IllegalArgumentException.class, () -> cartService.sumUpCartValue(List.of("Tomato")));
    }
}
