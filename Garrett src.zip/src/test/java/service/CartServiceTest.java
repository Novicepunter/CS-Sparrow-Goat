package service;

import org.assertj.core.util.BigDecimalComparator;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CartServiceTest {

    private final CartService cartService = new CartService();

    @Test
    public void shouldAddUpApplesCorrectly() {
        assertThat(cartService.sumUpCartValue(List.of("Apple","Apple","Apple")))
            .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
            .isEqualByComparingTo(BigDecimal.valueOf(1.05));
    }

    @Test
    public void shouldAddUpBananasCorrectly() {
        assertThat(cartService.sumUpCartValue(List.of("Banana","Banana","Banana")))
            .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
            .isEqualByComparingTo(BigDecimal.valueOf(0.60));
    }

    @Test
    public void shouldAddUpMelonsCorrectly() {
        assertThat(cartService.sumUpCartValue(List.of("Melon","Melon","Melon","Melon")))
            .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
            .isEqualByComparingTo(BigDecimal.valueOf(1.00));
    }

    @Test
    public void shouldAddUpLimesCorrectly() {
        assertThat(cartService.sumUpCartValue(List.of("Lime","Lime","Lime","Lime","Lime","Lime")))
            .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
            .isEqualByComparingTo(BigDecimal.valueOf(0.60));
    }

    @Test
    public void shouldAddUpMixCorrectly() {
        assertThat(cartService.sumUpCartValue(List.of("Apple","Apple","Apple","Banana","Banana","Banana","Melon","Melon","Melon","Melon","Lime","Lime","Lime","Lime","Lime","Lime")))
            .usingComparatorForType(BigDecimalComparator.BIG_DECIMAL_COMPARATOR, BigDecimal.class)
            .isEqualByComparingTo(BigDecimal.valueOf(3.25));
    }

    @Test
    public void shouldThrowAnExceptionIfNotRealFruit() {
        assertThrows(IllegalArgumentException.class, () -> cartService.sumUpCartValue(List.of("Tomato")));
    }
}
