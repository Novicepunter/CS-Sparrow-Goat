package deals;

import org.assertj.core.util.BigDecimalComparator;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;


public class StandardDealTest {
    private StandardDeal standardDeal = new StandardDeal();

    @ParameterizedTest
    @MethodSource("standardDealSource")
    public void shouldCalculateStandardDeal(Integer numberOfFruit, BigDecimal singleItemPrice, BigDecimal totalPrice) {
        assertThat(totalPrice)
            .usingComparator(BigDecimalComparator.BIG_DECIMAL_COMPARATOR)
            .isEqualTo(standardDeal.calculateTotalPrice(numberOfFruit, singleItemPrice));
    }

    private static Stream<Arguments> standardDealSource() {
        return Stream.of(
            Arguments.of(1, BigDecimal.valueOf(5), BigDecimal.valueOf(5)),
            Arguments.of(2, BigDecimal.valueOf(5), BigDecimal.valueOf(10)),
            Arguments.of(3, BigDecimal.valueOf(5), BigDecimal.valueOf(15))
        );
    }
}
