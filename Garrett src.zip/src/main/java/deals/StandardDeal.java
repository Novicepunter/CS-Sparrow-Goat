package deals;

import java.math.BigDecimal;

public class StandardDeal implements Deal {
    @Override
    public BigDecimal calculateTotalPrice(Integer numberOfFruit, BigDecimal singleItemPrice) {
        return singleItemPrice.multiply(BigDecimal.valueOf(numberOfFruit));
    }
}
