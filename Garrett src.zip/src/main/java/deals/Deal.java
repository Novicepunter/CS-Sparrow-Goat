package deals;

import java.math.BigDecimal;

public interface Deal {
    BigDecimal calculateTotalPrice(Integer numberOfFruit, BigDecimal singleItemPrice);
}
