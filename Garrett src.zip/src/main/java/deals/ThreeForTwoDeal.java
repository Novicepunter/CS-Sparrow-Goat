package deals;

import java.math.BigDecimal;

public class ThreeForTwoDeal implements Deal {
    @Override
    public BigDecimal calculateTotalPrice(Integer numberOfFruit, BigDecimal singleItemPrice) {
        var numberOfTriples = BigDecimal.valueOf(numberOfFruit / 3);
        var discount = numberOfTriples.multiply(singleItemPrice);
        var numberOfFruitBd = BigDecimal.valueOf(numberOfFruit);

        return singleItemPrice.multiply(numberOfFruitBd).subtract(discount);
    }
}
