package deals;

import java.math.BigDecimal;

public class TwoForOneDeal implements Deal {
    @Override
    public BigDecimal calculateTotalPrice(Integer numberOfFruit, BigDecimal singleItemPrice) {
        var numberOfDoubles = BigDecimal.valueOf(numberOfFruit / 2);
        var discount = numberOfDoubles.multiply(singleItemPrice);
        var numberOfFruitBd = BigDecimal.valueOf(numberOfFruit);

        return singleItemPrice.multiply(numberOfFruitBd).subtract(discount);
    }
}
