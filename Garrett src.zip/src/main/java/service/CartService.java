package service;

import model.Fruit;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CartService {

    public BigDecimal sumUpCartValue(List<String> fruitsInBasket) {
        var fruitFrequencyMap = fruitsInBasket.stream()
            .map(String::toUpperCase)
            .map(Fruit::valueOf)
            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        return addUpFruitValues(fruitFrequencyMap);
    }

    private static BigDecimal addUpFruitValues(Map<Fruit, Long> fruitFrequencyMap) {
        var cartValueInPence = fruitFrequencyMap.entrySet().stream()
            .map(e -> e.getKey().calculateActualPrice(e.getValue().intValue()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        return cartValueInPence.divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_DOWN);
    }
}
