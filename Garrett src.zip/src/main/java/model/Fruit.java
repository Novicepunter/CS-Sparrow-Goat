package model;

import deals.Deal;
import deals.StandardDeal;
import deals.ThreeForTwoDeal;
import deals.TwoForOneDeal;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

@RequiredArgsConstructor
public enum Fruit {
    APPLE(BigDecimal.valueOf(35), new StandardDeal()),
    BANANA(BigDecimal.valueOf(20), new StandardDeal()),
    MELON(BigDecimal.valueOf(50), new TwoForOneDeal()),
    LIME(BigDecimal.valueOf(15), new ThreeForTwoDeal());

    private final BigDecimal singleItemPrice;
    private final Deal deal;

    public BigDecimal calculateActualPrice(int numberOfItems) {
        return deal.calculateTotalPrice(numberOfItems, singleItemPrice);
    }

}
