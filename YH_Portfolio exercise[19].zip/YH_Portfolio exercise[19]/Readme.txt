***************************************
 * Sample Java coded that generates a basket of products
 * as an array of String.
 * Then computes the value of the porfolio
 * from a list price contained in a hashmap
****************************************

Source code is contined in:
    \Basket\src\com\company
and includes four files:
    - Main.java
    - Portfolio.java
    - ProductEnum.java
    - ProductList.java
