package com.company;

import java.util.HashMap;

public class ProductList {

    HashMap<ProductEnum, Double> ProductPrices;

    public ProductList()
    {
        // default constructor
        ProductPrices = new HashMap<ProductEnum, Double>();
    }

    public void init()
    {
        ProductPrices.put(ProductEnum.Apple, 0.8);
        ProductPrices.put(ProductEnum.Avocado, 1.2);
        ProductPrices.put(ProductEnum.Eggplant, 0.7);
        ProductPrices.put(ProductEnum.Grape, 3.1);
        ProductPrices.put(ProductEnum.Orange, 2.3);
    }

    public double getPrice(int n)
    {
        //System.out.println(n+" "+ProductEnum.getEnum(n));
        if(n < 6 ) // number of productid
            return ProductPrices.get(ProductEnum.getEnum(n));
        else
            return -1;
    }
}