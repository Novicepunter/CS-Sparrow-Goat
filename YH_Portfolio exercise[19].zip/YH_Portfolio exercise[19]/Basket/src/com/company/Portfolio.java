package com.company;

import java.util.Random;
import java.lang.Math;

public class Portfolio {

    int size = 10; // default number of items in basket
    int nproducts = 5; // number of products
    String[] productArray;

    // default contructor, random portfolio
    public Portfolio(int n ) {
        size = n;
        productArray = new String[n];
        long seed = System.currentTimeMillis();
        Random r = new Random(seed);

        for(int i = 0; i < n;i++)
        {
            int productId =(int)Math.floor((nproducts) * r.nextDouble()+1.0);
            //.out.println(productId);
            ProductEnum pe = ProductEnum.getEnum(productId);
            productArray[i] = pe.toString(); // fills the basket with n product items
        }
    }

    // deterministic portfolio
    public Portfolio(Integer[] productIds ) {
        size = productIds.length;
        productArray = new String[size];

        for(int i = 0; i < size;i++)
        {
            int productId = productIds[i];
            //.out.println(productId);
            ProductEnum pe = ProductEnum.getEnum(productId);
            productArray[i] = pe.toString(); // fills the basket with n product items
        }
    }

    public int getSize()
    {
        return size;
    }

}
