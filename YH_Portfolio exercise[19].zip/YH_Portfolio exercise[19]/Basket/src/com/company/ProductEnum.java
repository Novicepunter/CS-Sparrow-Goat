package com.company;

public enum  ProductEnum {
    Apple(1),
    Orange(2),
    Avocado(3),
    Eggplant(4),
    Grape(5);

    private int value;

    private ProductEnum(int value) {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }

    public static ProductEnum  getEnum(int value)
    {
        for (ProductEnum e:ProductEnum.values())
        {
            if(e.getValue() == value)
                return e;
        }

        return null;//For values out of enum scope
    }
}
