package com.company;

import java.io.Console;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        Portfolio portf = new Portfolio(10);

        ProductList priceList = new ProductList();
        priceList.init();

        System.out.println("Random Portfolio of ten items:");

        double total = 0;
        for(int i = 1 ; i < portf.getSize(); i++)
        {
            String s = portf.productArray[i];
            System.out.println("Portfolio has "+s);

            ProductEnum pe = ProductEnum.valueOf(s);
            total += priceList.getPrice(pe.getValue());
        }
        System.out.println("Total price of items in portfolio is "+total);

        System.out.println("");
        System.out.println("Deterministic portfolio of 5 items:");

        Portfolio portf5 = new Portfolio(new Integer[]{1,2,4,4,5});

        double total5 = 0;
        for(int i = 1 ; i < portf5.getSize(); i++)
        {
            String s = portf5.productArray[i];
            System.out.println("Portfolio has "+s);

            ProductEnum pe = ProductEnum.valueOf(s);
            total5 += priceList.getPrice(pe.getValue());
        }
        System.out.println("Deterministic portfolio value is "+total5);


    }
}


