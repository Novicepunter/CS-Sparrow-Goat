# Fruit-Basket-Price-Calculator

## Prerequisites

This is a basic maven project and the application compiles/runs on Java 11. 
Some basic unit tests have been added. 

## Running the Application

- Run `App.java` class to calculate Basket Price
- Run via test: `mvn test` 
- Add arguments to parameterized tests in `FruitPriceCalculatorImplTest` for more scenarios

Note: This code does not accept user input.
Kindly update the hardcoded list for different inputs.