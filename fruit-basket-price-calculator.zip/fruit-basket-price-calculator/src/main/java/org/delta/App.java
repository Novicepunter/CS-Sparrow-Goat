package org.delta;

import org.delta.basket.BasketPriceCalculator;

import java.math.BigDecimal;
import java.util.List;

/**
 * Total price of the fruit basket
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        final var fruits = List.of("apple", "banana","apple", "melon","melon", "melon", "lime", "lime", "lime");

        final BasketPriceCalculator basketPriceCalculator = new BasketPriceCalculator();
        final var totalPrice = basketPriceCalculator.getTotalBasketPrice(fruits);
        System.out.println( "Total price of Basket is: " + totalPrice+"p" );
    }


}
