package org.delta.basket;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;


public class FruitPriceCalculatorImpl implements FruitPriceCalculator {

    private final Function<Long, BigDecimal> toBigDecimal = BigDecimal::valueOf;

    @Override
    public BigDecimal calculateTotalPrice(final Map<String, Long> fruitsMeta) {
        return fruitsMeta.entrySet().stream()
                .map(u -> calculatePriceForFruit(u.getKey(), u.getValue()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private BigDecimal calculatePriceForFruit(final String fruit, final long count) {
        try {
            var meta = Fruits.valueOf(fruit.toUpperCase());
            if (Objects.nonNull(meta.getOffer()) && !meta.getOffer().isEmpty()) {
                if (meta.getOffer().equals("BOGO")) {
                    return buyOneGetOnePrice(count, meta);
                }
                if (meta.getOffer().equals("3For2")) {
                    return threeForPriceOfTwo(count, meta);
                }
            }
            return toBigDecimal.apply(meta.getPrice() * count);
        } catch (RuntimeException runtimeException){
            throw new RuntimeException("Item not Registered");
        }
    }

    private BigDecimal threeForPriceOfTwo(final long count, final Fruits meta) {
        final var value = count % 3 == 0 ? BigDecimal.valueOf(((meta.getPrice() * count) * 0.66))
                : toBigDecimal.apply((meta.getPrice() * count));
        return value.setScale(0, RoundingMode.UP);
    }

    private BigDecimal buyOneGetOnePrice(final long count, final Fruits meta) {
        return (count %2 == 0) ? toBigDecimal.apply((meta.getPrice() * count) / 2)
        : toBigDecimal.apply((meta.getPrice() * (count - 1)) / 2 + meta.getPrice());
    }
}
