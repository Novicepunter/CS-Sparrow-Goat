package org.delta.basket;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class BasketPriceCalculator {

    public BigDecimal getTotalBasketPrice(final List<String> fruits) {

        final FruitPriceCalculator fruitPriceCalculator = new FruitPriceCalculatorImpl();
        final var fruitsMeta = fruits.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        return fruitPriceCalculator.calculateTotalPrice(fruitsMeta);
    }
}
