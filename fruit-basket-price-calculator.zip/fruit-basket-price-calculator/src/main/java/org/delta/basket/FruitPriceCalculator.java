package org.delta.basket;

import java.math.BigDecimal;
import java.util.Map;

public interface FruitPriceCalculator {
    BigDecimal calculateTotalPrice(Map<String, Long> fruits);
}
