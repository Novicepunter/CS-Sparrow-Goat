package org.delta.basket;

public enum Fruits {
    APPLE("apple", 35, null),
    BANANA("banana", 20, null),
    MELON("melon", 50, "BOGO"),
    LIME("lime", 15, "3For2");

    private final String name;
    private final int price;
    private final String offer;

    private Fruits(final String name, final int price, final String offer) {
        this.name = name;
        this.price = price;
        this.offer = offer;
    }

    public String getName() {
        return name;
    }

    public String getOffer() {
        return offer;
    }

    public int getPrice() {
        return price;
    }
}
