package org.delta.basket;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BasketPriceCalculatorTest {
    final BasketPriceCalculator basketPriceCalculator = new BasketPriceCalculator();
    final FruitPriceCalculator fruitPriceCalculator = mock(FruitPriceCalculatorImpl.class);
    @Test
    void shouldCalculateTotalBasketPrice() {
        when(fruitPriceCalculator.calculateTotalPrice(any())).thenReturn(BigDecimal.valueOf(85));

        final var result = basketPriceCalculator.getTotalBasketPrice(List.of("Apple", "Melon"));
        assertEquals(result, BigDecimal.valueOf(85));
    }
}
