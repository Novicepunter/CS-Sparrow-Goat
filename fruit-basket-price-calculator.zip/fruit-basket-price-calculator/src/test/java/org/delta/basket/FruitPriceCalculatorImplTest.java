package org.delta.basket;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class FruitPriceCalculatorImplTest {

    final FruitPriceCalculator fruitPriceCalculator = new FruitPriceCalculatorImpl();

    @ParameterizedTest
    @MethodSource("provideInputAndAssertions")
    void shouldCalculateTotalBasketPrice(final Map<String, Long> fruitsMeta, final BigDecimal expected) {
        final var actual = fruitPriceCalculator.calculateTotalPrice(fruitsMeta);
        assertEquals(expected, actual);
    }

    @Test
    void shouldThrowExceptionForUnregisteredItem() {
        final var fruitsMeta = Map.of("Orange",Long.valueOf(2));
        assertThrows(RuntimeException.class, () -> {
            fruitPriceCalculator.calculateTotalPrice(fruitsMeta);
        });
    }

    // add more arguments to scenarios
    private static Stream<Arguments> provideInputAndAssertions() {
        Map<String, Long> allFruits = new HashMap<>();
        allFruits.put("Melon",Long.valueOf(2));
        allFruits.put("banana",Long.valueOf(1));
        allFruits.put("apple",Long.valueOf(1));
        allFruits.put("lime",Long.valueOf(3));

        return Stream.of(
                Arguments.of(Map.of("Melon",Long.valueOf(20)), BigDecimal.valueOf(500)),
                Arguments.of(Map.of("Apple",Long.valueOf(2)), BigDecimal.valueOf(70)),
                Arguments.of(Map.of("banana",Long.valueOf(5)), BigDecimal.valueOf(100)),
                Arguments.of(Map.of("lime",Long.valueOf(3)), BigDecimal.valueOf(30)),
                Arguments.of(allFruits, BigDecimal.valueOf(135))
        );
    }
}
