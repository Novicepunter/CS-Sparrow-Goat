package com.delta.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;


@RunWith(MockitoJUnitRunner.class)
public class BuyOneGetOneOfferTest {

    @InjectMocks
    private BuyOneGetOneOffer buyOneGetOneOffer = new BuyOneGetOneOffer();

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void calculateAmountWithCount8() {
        BigDecimal amount = buyOneGetOneOffer.calculateAmount(new BigDecimal("0.50"), 8l);
        assertEquals(new BigDecimal("2.00"), amount);
    }

    @Test
    public void calculateAmountWithCount1() {
        BigDecimal amount = buyOneGetOneOffer.calculateAmount(new BigDecimal("0.50"), 1l);
        assertEquals(new BigDecimal("0.50"), amount);
    }

    @Test
    public void calculateAmountWithCount7() {
        BigDecimal amount = buyOneGetOneOffer.calculateAmount(new BigDecimal("0.50"), 7l);
        assertEquals(new BigDecimal("2.00"), amount);
    }

    @Test
    public void calculateAmountWithCount0() {
        BigDecimal amount = buyOneGetOneOffer.calculateAmount(new BigDecimal("0.50"), 0l);
        assertEquals(new BigDecimal("0.00"), amount);
    }
}