package com.delta.impl;

import com.delta.interfaces.FruitBasket;
import com.delta.enums.Fruits;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class FruitBasketImplTest {

    @InjectMocks
    private FruitBasket fruitBasket = new FruitBasketImpl();

    private List<Fruits> fruitsList;

    @Before
    public void setUp() throws Exception {
        fruitsList = createFruitsList();
    }

    private List<Fruits> createFruitsList() {
        List<Fruits> fruitsList = new ArrayList<>();
        fruitsList.add(Fruits.APPLE);
        fruitsList.add(Fruits.BANANA);
        fruitsList.add(Fruits.MELON);
        fruitsList.add(Fruits.LIME);
        return fruitsList;
    }

    @Test
    public void getFruitBasketWithNoOfferCost() {
        BigDecimal amount = fruitBasket.getFruitBasketCost(fruitsList);
        assertTrue(new BigDecimal("1.20").equals(amount));
    }

    @Test
    public void getFruitBasketWithBuyOneGetOneOfferCost() {
        fruitsList.add(Fruits.MELON);
        BigDecimal amount = fruitBasket.getFruitBasketCost(fruitsList);
        assertTrue(new BigDecimal("1.20").equals(amount));
    }

    @Test
    public void getFruitBasketWithThreeForTwoOfferCost() {
        fruitsList.add(Fruits.LIME);
        fruitsList.add(Fruits.LIME);
        BigDecimal amount = fruitBasket.getFruitBasketCost(fruitsList);
        assertTrue(new BigDecimal("1.35").equals(amount));
    }

    @Test
    public void getFruitBasketWithAllOfferCost() {
        List<Fruits> selectedFruitsList = new ArrayList<>();
        selectedFruitsList.add(Fruits.LIME);
        selectedFruitsList.add(Fruits.LIME);
        selectedFruitsList.add(Fruits.MELON);
        BigDecimal amount = fruitBasket.getFruitBasketCost(selectedFruitsList);
        assertTrue(new BigDecimal("0.80").equals(amount));
    }

    @Test
    public void getFruitBasketWithSelectedFruitCost() {
        List<Fruits> selectedFruitsList = new ArrayList<>();
        selectedFruitsList.add(Fruits.LIME);
        selectedFruitsList.add(Fruits.LIME);
        selectedFruitsList.add(Fruits.MELON);
        BigDecimal amount = fruitBasket.getFruitBasketCost(selectedFruitsList);
        assertTrue(new BigDecimal("0.80").equals(amount));
    }

    @Test
    public void getEmptyFruitBasketCost() {
        List<Fruits> selectedFruitsList = new ArrayList<>();
        BigDecimal amount = fruitBasket.getFruitBasketCost(selectedFruitsList);
        assertTrue(new BigDecimal("0.00").equals(amount));
    }
}