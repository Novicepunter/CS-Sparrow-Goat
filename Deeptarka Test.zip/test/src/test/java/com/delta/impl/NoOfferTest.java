package com.delta.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class NoOfferTest {

    @InjectMocks
    private NoOffer noOffer = new NoOffer();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void calculateAmountWithNoOffer() {
        BigDecimal amount = noOffer.calculateAmount(new BigDecimal("0.35"), 2l);
        assertEquals(new BigDecimal("0.70"), amount);
    }

    @Test
    public void calculateAmountWithNoOfferOnZeroCount() {
        BigDecimal amount = noOffer.calculateAmount(new BigDecimal("0.35"), 0l);
        assertEquals(new BigDecimal("0.00"), amount);
    }
}