package com.delta.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;


@RunWith(MockitoJUnitRunner.class)
public class ThreeForTwoOfferTest {

    @InjectMocks
    private ThreeForTwoOffer threeForTwoOffer = new ThreeForTwoOffer();

    @Test
    public void calculateAmountWithCount3() {
        BigDecimal amount = threeForTwoOffer.calculateAmount(new BigDecimal("0.15"), 3l);
        assertEquals(new BigDecimal("0.30"), amount);
    }

    @Test
    public void calculateAmountWithCount2() {
        BigDecimal amount = threeForTwoOffer.calculateAmount(new BigDecimal("0.15"), 2l);
        assertEquals(new BigDecimal("0.30"), amount);
    }

    @Test
    public void calculateAmountWithCount0() {
        BigDecimal amount = threeForTwoOffer.calculateAmount(new BigDecimal("0.15"), 0l);
        assertEquals(new BigDecimal("0.00"), amount);
    }

    @Test
    public void calculateAmountWithCount5() {
        BigDecimal amount = threeForTwoOffer.calculateAmount(new BigDecimal("0.15"), 5l);
        assertEquals(new BigDecimal("0.60"), amount);
    }
}