package com.delta.impl;

import com.delta.interfaces.Offer;

import java.math.BigDecimal;

public class NoOffer implements Offer {


    @Override
    public BigDecimal calculateAmount(BigDecimal amount, Long count) {
        BigDecimal totalAmount = amount.multiply(BigDecimal.valueOf(count));
        return totalAmount;
    }
}
