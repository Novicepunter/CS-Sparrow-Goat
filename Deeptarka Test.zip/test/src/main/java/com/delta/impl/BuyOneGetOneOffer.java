package com.delta.impl;

import com.delta.interfaces.Offer;

import java.math.BigDecimal;

public class BuyOneGetOneOffer implements Offer {
    @Override
    public BigDecimal calculateAmount(BigDecimal amount, Long count) {
        BigDecimal totalAmount = new BigDecimal("0.0");
        if (count%2 == 0) {
            totalAmount = totalAmount.add(amount.multiply(BigDecimal.valueOf(count)).divide(BigDecimal.valueOf(2)));
        }
        else {
            totalAmount = totalAmount.add(amount.multiply(BigDecimal.valueOf(count/2)).add(amount.multiply(BigDecimal.valueOf(count%2))));
        }

        return totalAmount;
    }
}
