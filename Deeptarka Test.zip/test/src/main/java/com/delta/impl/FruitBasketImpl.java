package com.delta.impl;

import com.delta.interfaces.FruitBasket;
import com.delta.enums.Fruits;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FruitBasketImpl implements FruitBasket {

    @Override
    public BigDecimal getFruitBasketCost(List<Fruits> fruitsList) {
        BigDecimal totalCost = new BigDecimal("0.00");
        if (CollectionUtils.isNotEmpty(fruitsList)) {
            Map<Fruits, Long> fruitCountMap = this.getFruitCount(fruitsList);
            totalCost = (fruitCountMap.entrySet().stream().map(
                    e -> e.getKey().getOffer().calculateAmount(e.getKey().getValue(), e.getValue()))
                    .reduce(BigDecimal.ZERO, (p,q)-> p.add(q),BigDecimal::add));
        }

        return totalCost;

    }

    private Map<Fruits, Long> getFruitCount(List<Fruits> fruitsList) {
        Map<Fruits, Long> counted = fruitsList.stream()
                    .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        return counted;

    }



}
