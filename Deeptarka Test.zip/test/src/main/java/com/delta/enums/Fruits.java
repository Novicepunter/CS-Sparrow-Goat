package com.delta.enums;

import com.delta.impl.BuyOneGetOneOffer;
import com.delta.impl.NoOffer;
import com.delta.impl.ThreeForTwoOffer;
import com.delta.interfaces.Offer;

import java.math.BigDecimal;

public enum Fruits {
    APPLE("Apple", new NoOffer(), new BigDecimal("0.35")), BANANA("Banana", new NoOffer(), new BigDecimal("0.20")),MELON("melon", new BuyOneGetOneOffer(),new BigDecimal("0.50")),LIME("lime", new ThreeForTwoOffer(), new BigDecimal("0.15"));


    private String name;
    private Offer offer;
    private BigDecimal value;


    private Fruits(String name, Offer offer, BigDecimal value) {
        this.name = name;
        this.offer = offer;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public Offer getOffer() {
        return offer;
    }

    public BigDecimal getValue() {
        return value;
    }
}
