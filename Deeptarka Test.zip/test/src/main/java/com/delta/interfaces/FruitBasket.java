package com.delta.interfaces;

import com.delta.enums.Fruits;

import java.math.BigDecimal;
import java.util.List;

public interface FruitBasket {

    BigDecimal getFruitBasketCost(List<Fruits> fruitsList);
}
