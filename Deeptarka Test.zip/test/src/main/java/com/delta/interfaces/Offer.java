package com.delta.interfaces;

import java.math.BigDecimal;

public interface Offer {

    BigDecimal calculateAmount(BigDecimal amount, Long count);
}
