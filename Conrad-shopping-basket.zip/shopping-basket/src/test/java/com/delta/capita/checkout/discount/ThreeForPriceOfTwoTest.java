package com.delta.capita.checkout.discount;

import static org.assertj.core.api.Assertions.assertThat;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import com.delta.capita.product.ProductType;
import com.delta.capita.product.ShoppingCartItem;

public class ThreeForPriceOfTwoTest {

  
  @Test
  public void test_that_discount_is_applied_correctly() {
    // given
   
    ShoppingCartItem apple = new ShoppingCartItem(ProductType.APPLE);
    ShoppingCartItem banana = new ShoppingCartItem(ProductType.BANANA); 
    ThreeForPriceOfTwo threeForPriceOfTwo = new ThreeForPriceOfTwo(ProductType.APPLE);
    
    final List<ShoppingCartItem> basket = new ArrayList<>();
    
    basket.add(apple);
    basket.add(apple);
    basket.add(apple);
    basket.add(apple);
    basket.add(apple);
    basket.add(apple);
    
    basket.add(banana);
    basket.add(banana);
    
    // when
    BigDecimal discount = threeForPriceOfTwo.applyDiscount(basket);
    
    //then 
    assertThat(discount).isEqualByComparingTo(BigDecimal.valueOf(0.70));
    
  }
  
  @Test
  public void test_that_no_discount_is_applied_when_shppoing_cart_contains_no_discounted_items() {
    // given
    List<ShoppingCartItem> basket = new ArrayList<>();
    ShoppingCartItem apple = new ShoppingCartItem(ProductType.APPLE);
    ThreeForPriceOfTwo threeForPriceOfTwo = new ThreeForPriceOfTwo(ProductType.BANANA);
    basket.add(apple);
    basket.add(apple);
    basket.add(apple);
 
    // when
    BigDecimal discount = threeForPriceOfTwo.applyDiscount(basket);
    
    //then 
    assertThat(discount).isEqualByComparingTo(BigDecimal.ZERO);
    
  }

}
