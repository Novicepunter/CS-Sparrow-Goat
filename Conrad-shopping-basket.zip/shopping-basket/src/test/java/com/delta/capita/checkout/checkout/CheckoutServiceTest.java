package com.delta.capita.checkout.checkout;

import static org.assertj.core.api.Assertions.assertThat;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import com.delta.capita.checkout.CheckoutService;
import com.delta.capita.checkout.discount.BuyOneGetOneFree;
import com.delta.capita.checkout.discount.Discount;
import com.delta.capita.checkout.discount.ThreeForPriceOfTwo;
import com.delta.capita.product.ProductType;
import com.delta.capita.product.ShoppingCartItem;

public class CheckoutServiceTest {

  private final CheckoutService service = new CheckoutService();
  private final ShoppingCartItem melon = new ShoppingCartItem(ProductType.MELON);
  private final ShoppingCartItem lime = new ShoppingCartItem(ProductType.LIME);
  private final ShoppingCartItem apple = new ShoppingCartItem(ProductType.APPLE);
  private final ShoppingCartItem banana = new ShoppingCartItem(ProductType.BANANA);
    
  

  @Test
  public void test_that_basket_total_is_calculated_correctly() {
    // given
    Discount buyOneGetOneFreeMelons = new BuyOneGetOneFree(ProductType.MELON);
    Discount threeForPriceOfTwo = new ThreeForPriceOfTwo(ProductType.LIME);
    
    List<ShoppingCartItem> basket = Arrays.asList(apple, apple, banana, melon, melon, melon, melon, lime, lime, lime, lime, lime, lime);

    service.addDiscount(buyOneGetOneFreeMelons);
    service.addDiscount(threeForPriceOfTwo);
    
    // when
    BigDecimal total = service.calculatePrice(basket);

    // then
    assertThat(total).isEqualByComparingTo(BigDecimal.valueOf(2.50));

  }
  
  @Test
  public void test_that_total_price_is_zero_when_shoppingCart_is_empty() {
    // given
    Discount buyOneGetOneFreeMelons = new BuyOneGetOneFree(ProductType.MELON);
    Discount threeForPriceOfTwo = new BuyOneGetOneFree(ProductType.LIME);
    
    List<ShoppingCartItem> basket = new ArrayList<>() ;

    service.addDiscount(buyOneGetOneFreeMelons);
    service.addDiscount(threeForPriceOfTwo);
    
    // when
    BigDecimal total = service.calculatePrice(basket);

    // then
    assertThat(total).isEqualByComparingTo(BigDecimal.ZERO);

  }
  
  @Test
  public void test_that_total_price_is_calculated_correctly_when_no_discounts_are_available() {
    // given 
    List<ShoppingCartItem> basket = Arrays.asList(apple, apple, banana, melon, lime);
    
    // when
    BigDecimal total = service.calculatePrice(basket);

    // then
    assertThat(total).isEqualByComparingTo(BigDecimal.valueOf(1.55));

  }

}
