package com.delta.capita.checkout;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.delta.capita.checkout.discount.Discount;
import com.delta.capita.product.ShoppingCartItem;

/**
 * The {@link CheckoutService} will be used to calculate the items in a shopping cart. The service
 * will register all the discounts available to the system and use them to calculate the final
 * price.
 * 
 * @author Conrad
 *
 */
public class CheckoutService implements Checkout {

  private final ReentrantLock discountLock = new ReentrantLock();
  private final ReentrantLock checkoutLock = new ReentrantLock();
  private final Set<Discount> discounts = new HashSet<>();
  private static final Logger LOG = LoggerFactory.getLogger(CheckoutService.class);


  @Override
  public void addDiscount(Discount discount) {
    try {
      discountLock.lock();

      discounts.add(discount);

    } finally {
      discountLock.unlock();
    }
  }


  @Override
  public BigDecimal calculatePrice(List<ShoppingCartItem> basket) {

    BigDecimal total = BigDecimal.ZERO;
    LOG.debug("Calculating price, basket = {}", basket);

    try {

      checkoutLock.lock();

      total = basket.stream()
                    .map(ShoppingCartItem::getPrice)
                    .reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO);


      BigDecimal discount = discounts.stream()
                                     .map(d -> d.applyDiscount(basket))
                                     .reduce(BigDecimal::add)
                                     .orElse(BigDecimal.ZERO);

      total = total.subtract(discount);
      
      LOG.debug("Total price = {}", total);

    } finally {
      checkoutLock.unlock();
    }

    

    return total;
  }
}
