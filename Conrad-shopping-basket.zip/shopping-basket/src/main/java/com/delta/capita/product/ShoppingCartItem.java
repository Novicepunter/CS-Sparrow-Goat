package com.delta.capita.product;

import java.math.BigDecimal;

public class ShoppingCartItem {
  
  private final ProductType product;
  
  public ShoppingCartItem(ProductType type) {
    this.product = type;
 
  }
  
  

  public ProductType getProduct() {
    return product;
  }
  
  public BigDecimal getPrice() {
    return product.getPrice();
  }



  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((product == null) ? 0 : product.hashCode());
    return result;
  }



  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ShoppingCartItem other = (ShoppingCartItem) obj;
    if (product != other.product)
      return false;
    return true;
  }



  @Override
  public String toString() {
    return "ShoppingCartItem [type=" + product + "]";
  }

  
}
