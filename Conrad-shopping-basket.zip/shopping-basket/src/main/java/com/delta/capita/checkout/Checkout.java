package com.delta.capita.checkout;

import java.math.BigDecimal;
import java.util.List;
import com.delta.capita.checkout.discount.Discount;
import com.delta.capita.product.ShoppingCartItem;

public interface Checkout {
  
  public void addDiscount(Discount discount);
  
  public BigDecimal calculatePrice(List<ShoppingCartItem> basket);
  
  // we can add more methods e.g. remove etc 
  
}
