package com.delta.capita.checkout.discount;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import com.delta.capita.product.ProductType;
import com.delta.capita.product.ShoppingCartItem;

public class BuyOneGetOneFree implements Discount {

  private final ProductType productType;

  public BuyOneGetOneFree(ProductType productType) {
    this.productType = productType;
  }


  @Override
  public ProductType getProductType() {
    return productType;
  }

  @Override
  public BigDecimal applyDiscount(List<ShoppingCartItem> productList) {

    BigDecimal price = BigDecimal.ZERO;
    List<ShoppingCartItem> items = productList.stream()
                                         .filter(p -> productType == p.getProduct())
                                         .collect(Collectors.toList());

    if (items.size() > 1) {

      int totalItems = items.size();
      

      int free = totalItems - (totalItems / 2);
      price = productType.getPrice().multiply(BigDecimal.valueOf(free));
      
    }

    return price;

  }

}
