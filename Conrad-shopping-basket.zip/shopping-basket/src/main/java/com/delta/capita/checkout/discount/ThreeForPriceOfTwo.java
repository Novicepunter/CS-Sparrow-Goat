package com.delta.capita.checkout.discount;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import com.delta.capita.product.ProductType;
import com.delta.capita.product.ShoppingCartItem;

public class ThreeForPriceOfTwo  implements Discount {
  
  
  private final ProductType productType;
  
  public ThreeForPriceOfTwo(ProductType product) {
    this.productType = product ;
  }

  @Override
  public ProductType getProductType() {
    
    return productType;
  }

  @Override
  public BigDecimal applyDiscount(List<ShoppingCartItem> productList) {
    
    BigDecimal price = BigDecimal.ZERO;
    
    List<ShoppingCartItem> items = productList.stream()
                                         .filter(p -> productType ==p.getProduct())
                                         .collect(Collectors.toList());
    
    if (items.size() > 3) {
      final int totalItems = items.size();
      ShoppingCartItem shoppingCartItem = items.get(0);
      
      int discount = (totalItems / 3);
      price = shoppingCartItem.getPrice().multiply(BigDecimal.valueOf(discount));
      
    }
    
    return price;
  }

}
