package com.delta.capita.product;

import java.math.BigDecimal;

public enum ProductType {
  APPLE(BigDecimal.valueOf(0.35)), 
  BANANA(BigDecimal.valueOf(0.20)), 
  LIME(BigDecimal.valueOf(0.15)), 
  MELON(BigDecimal.valueOf(0.50));

  private final BigDecimal price;

  private ProductType(BigDecimal price) {
    this.price = price;
  }

  public BigDecimal getPrice() {
    return price;
  }


}
