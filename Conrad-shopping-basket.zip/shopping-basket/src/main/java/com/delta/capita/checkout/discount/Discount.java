package com.delta.capita.checkout.discount;

import java.math.BigDecimal;
import java.util.List;
import com.delta.capita.product.ProductType;
import com.delta.capita.product.ShoppingCartItem;

public interface Discount  {
  
  public ProductType getProductType();
  
  public BigDecimal applyDiscount(List<ShoppingCartItem> productList);

}
