package model;

import java.math.BigDecimal;

public class Default implements Offer {
    @Override
    public BigDecimal calculatePriceForAmount(long amount, BigDecimal unitPrice) {
        BigDecimal amt = new BigDecimal(String.valueOf(amount));
        return amt.multiply(unitPrice);
    }
}
