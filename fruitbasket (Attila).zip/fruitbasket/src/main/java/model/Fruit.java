package model;

import java.math.BigDecimal;

public enum Fruit {
    APPLE(35, new Default()),
    BANANA(20, new Default()),
    MELON(50, new TwoForOne()),
    LIME(15, new ThreeForTwo());

    private BigDecimal price;

    public BigDecimal getPrice() {
        return price;
    }

    public Offer getOffer() {
        return offer;
    }

    private Offer offer;

    Fruit(int price, Offer offer) {
        this.price = new BigDecimal(String.valueOf(price));
        this.offer = offer;
    }
}
