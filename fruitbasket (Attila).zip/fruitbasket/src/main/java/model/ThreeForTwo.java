package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ThreeForTwo implements Offer {
    static BigDecimal amountRequiredToTriggerOffer = new BigDecimal(String.valueOf("3"));

    @Override
    public BigDecimal calculatePriceForAmount(long amount, BigDecimal unitPrice) {
        BigDecimal amt = new BigDecimal(String.valueOf(amount));
        if (amount < amountRequiredToTriggerOffer.intValue()) {
            return amt.multiply(unitPrice);
        }
        BigDecimal remainder = amt.remainder(amountRequiredToTriggerOffer);
        return amt
                .subtract(remainder)
                .divide(amountRequiredToTriggerOffer, RoundingMode.HALF_UP)
                .multiply(unitPrice.add(unitPrice))
                .add(remainder.multiply(unitPrice));
    }
}
