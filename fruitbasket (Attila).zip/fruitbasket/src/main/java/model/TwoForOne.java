package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class TwoForOne implements Offer {
    static BigDecimal amountRequiredToTriggerOffer = new BigDecimal(String.valueOf("2"));

    @Override
    public BigDecimal calculatePriceForAmount(long amount, BigDecimal unitPrice) {
        BigDecimal amt = new BigDecimal(String.valueOf(amount));
        if (amount < amountRequiredToTriggerOffer.intValue()) {
            return amt.multiply(unitPrice);
        }
        BigDecimal remainder = amt.remainder(amountRequiredToTriggerOffer);
        return amt
                .subtract(remainder)
                .divide(amountRequiredToTriggerOffer, RoundingMode.HALF_UP)
                .add(remainder)
                .multiply(unitPrice);
    }
}
