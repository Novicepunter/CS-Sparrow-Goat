package model;

import java.math.BigDecimal;

public interface Offer {
    /**
     * Claculates the total price of item after applied the discount for the specified amount and unit price
     * @param amount the amount of items to apply the discount on
     * @param originalPrice the price of an individual item
     * @return the total price after the discount
     */
    BigDecimal calculatePriceForAmount(long amount, BigDecimal originalPrice);
}
