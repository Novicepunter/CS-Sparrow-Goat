package service;

import model.Fruit;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FruitBasket {
    private final List<Fruit> fruits;

    public FruitBasket(List<Fruit> fruits) {
        this.fruits = fruits;
    }

    /**
     * Get the total price of all given items after applying any discounts if applicable
     * @return the total price to pay
     */
    public BigDecimal getTotalPrice() {
        AtomicReference<BigDecimal> total = new AtomicReference<>(new BigDecimal("0"));
        fruits.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .forEach((fruit, amount) -> total.set(
                        total.get().add(fruit.getOffer()
                                .calculatePriceForAmount(amount, fruit.getPrice()))));
        return total
                .get()
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
    }
}
