package model;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static model.Fruit.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class OfferTest {

    private static Map<Fruit, BigDecimal> priceForTen;

    @BeforeAll
    static void setup() {
        priceForTen = new HashMap<>();
        priceForTen.put(APPLE, new BigDecimal(String.valueOf(350)));
        priceForTen.put(BANANA, new BigDecimal(String.valueOf(200)));
        priceForTen.put(MELON, new BigDecimal(String.valueOf(250)));
        priceForTen.put(LIME, new BigDecimal(String.valueOf(105)));
    }

    @ParameterizedTest
    @EnumSource(Fruit.class)
    void getTotalFor10(Fruit fruit) {
        BigDecimal price = fruit.getOffer().calculatePriceForAmount(10, fruit.getPrice());
        assertEquals(priceForTen.get(fruit), price);
    }

}