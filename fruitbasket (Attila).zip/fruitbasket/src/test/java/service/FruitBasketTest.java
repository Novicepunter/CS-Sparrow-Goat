package service;

import model.Fruit;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static model.Fruit.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FruitBasketTest {
    @Test
    void emptyBasket() {
        List<Fruit> fruits = new ArrayList<>();
        FruitBasket basket = new FruitBasket(fruits);
        assertEquals(new BigDecimal("0.00"), basket.getTotalPrice());
    }

    @Test
    void appleBasket() {
        List<Fruit> fruits = new ArrayList<>();
        fruits.add(APPLE);
        FruitBasket basket = new FruitBasket(fruits);
        assertEquals(new BigDecimal("0.35"), basket.getTotalPrice());
    }

    @Test
    void fullBasketOfTenEach() {
        List<Fruit> fruits = new ArrayList<>();
        for (int i =0; i < 10; i++) {
            fruits.add(APPLE);
            fruits.add(BANANA);
            fruits.add(MELON);
            fruits.add(LIME);
        }
        FruitBasket basket = new FruitBasket(fruits);
        //10*35+10*20+5*50+3*30+15=905=£9.05
        assertEquals(new BigDecimal("9.05"), basket.getTotalPrice());
    }
}