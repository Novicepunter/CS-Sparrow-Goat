package com.dc.calculate;

import java.math.BigDecimal;

public class CalculateUtil {

  private static int SCALE = 0;

  private CalculateUtil() {
  }

  /**
   * 3for2 a=3 b=2
   * @param num
   * @param a
   * @param b
   */
  public static long aForb(long num, long a,long b)
  {
    return ((num / a) )*b + (num % a);
  }

  public static BigDecimal multiplyNoScale(BigDecimal price, long count) {

	return new BigDecimal(count).multiply(price).setScale(SCALE);
  }


}
