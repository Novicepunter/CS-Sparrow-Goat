package com.dc.calculate;


import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class CalculateUtilCountAForBTest {


  @Parameters
  public static Collection<Object[]> data() {
    return Arrays.asList(new Object[][] {
            { 10, 4,2,6 },
            { 10, 5,1,2 },
            { 10, 15,1,10 },
            { 10, 2,1,5 },
            { 10, 1,1,10 },
            { 10, 10,1,1 },
            { 10, 4,2,6 },
            { 10, 3,2,7}
    });
  }


  private int num;

  //example  4 for 3 price, a=4
  private int a;

  //example  4 for 3 price, b=3
  private int b;

  private int expected;

  public CalculateUtilCountAForBTest(int inputNum, int inputA, int inputB, int inputExpected) {
    this.num = inputNum;
    this.a =inputA;
    this.b =inputB;
    this.expected = inputExpected;
  }


  @Test
  public void countAforB(){
    assertEquals(expected, CalculateUtil.aForb(num,a,b));
  }
}



