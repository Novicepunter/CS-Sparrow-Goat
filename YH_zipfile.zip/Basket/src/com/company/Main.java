package com.company;

import java.io.Console;

public class Main {


    public static double getcount(String[] arr) {
        double sum = 0.0;
        int n = arr.length;
        System.out.println("n="+n);

        for (int i = 0; i < arr.length; i++) {
            switch (arr[i]) {
                case "Apple":
                    sum += 0.25;
                    break;
                case "Bannana":
                    sum += 0.15;
                    break;
                case "Orange":
                    sum += 0.93;
                    break;
            }
        }
       // System.out.println(sum);
        return sum;
    }


    public static void main(String[] args) {
	// write your code here
        String basket[] = {"Apple","Bannana", "Bannana","Orange"};

        double sum = getcount(basket);
        System.out.println("sum="+sum);
    }
}


