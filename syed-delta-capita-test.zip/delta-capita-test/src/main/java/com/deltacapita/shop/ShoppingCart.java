package com.deltacapita.shop;

import com.deltacapita.shop.discount.Discount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    List<Item> itemsList;

    public ShoppingCart() {
        itemsList = new ArrayList<>();
    }

    public void addItem(Item item) {
        itemsList.add(item);
    }


    public BigDecimal getTotal(List<Discount> discounts) {
        return applyDiscountsAndTotal(discounts);
    }

    /**
     * Apply the discount when total is called
     * @return
     */
    private BigDecimal applyDiscountsAndTotal(List<Discount> discounts) {

        BigDecimal total = new BigDecimal("0");

        for(Discount discount: discounts){
            total = total.add(discount.apply(itemsList));
        }

        for (Item item : itemsList) {
            total = total.add(item.getPrice());
        }

        return total;
    }
}
