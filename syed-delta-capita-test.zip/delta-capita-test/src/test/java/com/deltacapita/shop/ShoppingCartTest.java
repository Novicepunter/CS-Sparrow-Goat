package com.deltacapita.shop;

import com.deltacapita.shop.discount.Discount;

import com.deltacapita.shop.discount.LimeDiscount;
import com.deltacapita.shop.discount.MelonDiscount;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

@RunWith(JUnit4.class)
public class ShoppingCartTest extends TestCase {
    private static final List<Discount> discountList = new ArrayList<>();
    public static final String MELON = "Melon";
    public static final String LIME_NAME = "Lime";
    public static final String APPLE_NAME = "Apple";
    public static final String BANANA_NAME = "Banana";
    public static final BigDecimal MELON_PRICE = new BigDecimal("50");
    public static final BigDecimal LIME_PRICE = new BigDecimal("15");
    public static final BigDecimal APPLE_PRICE = new BigDecimal("35");
    public static final BigDecimal BANANA_PRICE = new BigDecimal("20");
    public static final int ONE_ITEM = 1;

    @BeforeClass
    public static void setup() {
        Discount limeDiscount = new LimeDiscount();
        Discount melonDiscount = new MelonDiscount();
        discountList.add(limeDiscount);
        discountList.add(melonDiscount);
    }

    @Test
    public void testMelons() {
        Item melonItem = new Item(MELON, MELON_PRICE);
        testShoppingCartWithSameItems(1, melonItem, new BigDecimal("50"));
        testShoppingCartWithSameItems(2, melonItem, new BigDecimal("50"));
        testShoppingCartWithSameItems(3, melonItem, new BigDecimal("100"));
        testShoppingCartWithSameItems(4, melonItem, new BigDecimal("100"));
        testShoppingCartWithSameItems(5, melonItem, new BigDecimal("150"));
    }

    @Test
    public void testLimes() {
        Item limeItem = new Item(LIME_NAME, LIME_PRICE);
        testShoppingCartWithSameItems(1, limeItem, new BigDecimal("15"));
        testShoppingCartWithSameItems(2, limeItem, new BigDecimal("30"));
        testShoppingCartWithSameItems(3, limeItem, new BigDecimal("30"));
        testShoppingCartWithSameItems(4, limeItem, new BigDecimal("45"));
        testShoppingCartWithSameItems(5, limeItem, new BigDecimal("60"));
        testShoppingCartWithSameItems(6, limeItem, new BigDecimal("60"));
        testShoppingCartWithSameItems(7, limeItem, new BigDecimal("75"));
    }

    private void testShoppingCartWithSameItems(int howMany, Item item, BigDecimal expectedTotal) {
        ShoppingCart shoppingCart = new ShoppingCart();
        addItemsInShoppingCart(howMany, item, shoppingCart);
        Assert.assertEquals(shoppingCart.getTotal(discountList), expectedTotal);
    }

    @Test
    public void testFullShoppingCart() {
        ShoppingCart shoppingCart = new ShoppingCart();
        addItemsInShoppingCart(7, new Item(LIME_NAME, LIME_PRICE), shoppingCart);
        addItemsInShoppingCart(5, new Item(MELON, MELON_PRICE), shoppingCart);
        addItemsInShoppingCart(1, new Item(APPLE_NAME, APPLE_PRICE), shoppingCart);
        addItemsInShoppingCart(1, new Item(BANANA_NAME, BANANA_PRICE), shoppingCart);
        Assert.assertEquals(shoppingCart.getTotal(discountList), (new BigDecimal("280")));
    }

    private void addItemsInShoppingCart(int howMany, Item item, ShoppingCart shoppingCart) {
        IntStream.range(0, howMany).mapToObj(i -> item).forEach(shoppingCart::addItem);
    }

}