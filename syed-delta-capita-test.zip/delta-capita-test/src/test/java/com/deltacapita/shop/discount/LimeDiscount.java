package com.deltacapita.shop.discount;

import com.deltacapita.shop.Item;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;
import java.util.stream.Collectors;

public class LimeDiscount implements Discount {



    @Override
    public BigDecimal apply(List<Item> items) {

        // Buy 3 for price 2
        int limeDiscountFactor = 3;
        MathContext mc = new MathContext(2);
        List<Item> limes = items.stream().filter(item -> item.getName().equals("Lime")).collect(Collectors.toList());
        items.removeAll(limes);
        BigDecimal total = new BigDecimal("0");

        if (limes.isEmpty()) {
            return total;
        }
        if (limes.size() < limeDiscountFactor) {
            total = total.add(limes.get(0).getPrice().multiply(BigDecimal.valueOf(limes.size()), mc));
            return total;
        }
        if (limes.size() % limeDiscountFactor > 0) {
            int remaining = limes.size() % limeDiscountFactor;
            total = total.add(limes.get(0).getPrice().multiply(BigDecimal.valueOf(remaining)));
        }
        total = total.add(limes.get(0).getPrice().multiply(BigDecimal.valueOf((limes.size() / limeDiscountFactor) * 2), mc));
        return total;
    }
}
