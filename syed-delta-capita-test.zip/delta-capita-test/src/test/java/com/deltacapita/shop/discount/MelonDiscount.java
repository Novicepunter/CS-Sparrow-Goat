package com.deltacapita.shop.discount;

import com.deltacapita.shop.Item;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;
import java.util.stream.Collectors;

public class MelonDiscount implements Discount{

    @Override
    public BigDecimal apply(List<Item> items) {

        // buy 1 get 1 free
        int malonDiscountFactor = 2;
        MathContext mc = new MathContext(2);
        List<Item> melons = items.stream().filter(item -> item.getName().equals("Melon")).collect(Collectors.toList());
        items.removeAll(melons);

        BigDecimal total = new BigDecimal("0");

        if (!melons.isEmpty()) {
            if (melons.size() % malonDiscountFactor == 1) {
                total = total.add(melons.get(0).getPrice().multiply(BigDecimal.valueOf(1)));
            }
            total= total.add(melons.get(0).getPrice().multiply(BigDecimal.valueOf(melons.size() / malonDiscountFactor), mc));
        }
        return total;
    }



}
