import java.util.HashMap;
import java.util.Map;

/**
 * This class is created as a singleton class because same offers apply on all the shopping cart.
 * Any of the offer is added or removed should be updated for all the shopping cart.
 */
public class Offers {
    public static Offers offers = new Offers();
    private Map<String, Offer> offermap = new HashMap<>();

    public static Offers getOffersInstance() {
        return offers;
    }

    public void addOffer(String itemName, Offer offer) {
        this.offermap.put(itemName, offer);
    }

    public Offer getOffer(String itemName) {
        return offermap.get(itemName);
    }

    public void removeOffer(String itemName) {
        this.offermap.remove(itemName);
    }

}
