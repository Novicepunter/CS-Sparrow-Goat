import java.util.LinkedList;
import java.util.List;

public class ShoppingCart {
    private List<Item> itemList = new LinkedList<>();

    public List<Item> getItemList() {
        return itemList;
    }

    public void addItem(Item item) {
        itemList.add(item);
    }

    public void viewItems() {
        itemList.stream().forEach(item -> System.out.println(item.getItemName()));
    }

    public void removeItem(Item item) {
        itemList.remove(item);
    }
}
