public class Offer {
    private int noOfItems;
    private double priceToPay;

    public Offer(int noOfItems, double priceToPay) {
        this.noOfItems = noOfItems;
        this.priceToPay = priceToPay;
    }

    public int getNoOfItems() {
        return noOfItems;
    }

    public void setNoOfItems(int noOfItems) {
        this.noOfItems = noOfItems;
    }

    public double getPriceToPay() {
        return priceToPay;
    }

    public void setPriceToPay(double priceToPay) {
        this.priceToPay = priceToPay;
    }
}
