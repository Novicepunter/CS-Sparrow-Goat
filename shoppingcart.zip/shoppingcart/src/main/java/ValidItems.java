public enum ValidItems {
    LIME,
    MELON,
    BANANA,
    APPLE
}