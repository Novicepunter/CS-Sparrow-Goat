import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ShoppingCartCalculatorUtil {
    public static double calculateCartPrice(ShoppingCart shoppingCart) {

        Collection<Item> distinctItemsList = shoppingCart.getItemList().stream().collect(Collectors.toMap(Item::getItemName, Function.identity(), (item1, item2) -> item1)).values();
        AtomicReference<Double> cartPrice = new AtomicReference<>((double) 0);


        distinctItemsList.forEach(item -> {
            List<Item> itemList = shoppingCart.getItemList().stream().filter(i -> i.getItemName().equals(item.getItemName())).collect(Collectors.toList());
            Offer offer = Offers.getOffersInstance().getOffer(item.getItemName());

            if (offer != null) {
                cartPrice.updateAndGet(v -> new Double((double) (v + applyOffer(itemList, offer))));
            } else {
                cartPrice.updateAndGet(v -> new Double((double) (v + itemList.stream().collect(Collectors.summingDouble(Item::getItemPrice)))));
            }

        });

        return cartPrice.get();
    }

    public static double applyOffer(List<Item> itemList, Offer offer) {
        int offerQuantity = offer.getNoOfItems();
        double offerPrice = offer.getPriceToPay();
        double totalPrice = 0;
        int noOfItems = itemList.size();
        if (noOfItems < offerQuantity) {
            totalPrice = itemList.stream().collect(Collectors.summingDouble(Item::getItemPrice));
        } else {
            int n = noOfItems / offerQuantity;
            double r = Double.valueOf(noOfItems % offerQuantity);

            totalPrice = (n * offerPrice) + (r * itemList.get(0).getItemPrice());
        }

        return totalPrice;
    }
}
