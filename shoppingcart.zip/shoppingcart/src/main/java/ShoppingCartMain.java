import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * This is the main class to invoke the shopping cart calculator functionality.
 * It requires to provide the list of items in capital in command line. for example: java ShoppingCartMain LIME MELON APPLE BANANA
 * It requires to provide the updated rate list for items and offer details as pre-requisite.
 */
public class ShoppingCartMain {
    public static void main(String[] args) {

        Map<String, Double> updatedItemPriceMap = new HashMap<>();
        updatedItemPriceMap.put(ValidItems.APPLE.name(), 0.35);
        updatedItemPriceMap.put(ValidItems.BANANA.name(), 0.20);
        updatedItemPriceMap.put(ValidItems.MELON.name(), 0.50);
        updatedItemPriceMap.put(ValidItems.LIME.name(), 0.15);

        Offers offers = Offers.getOffersInstance();
        offers.addOffer(ValidItems.MELON.name(), new Offer(2, 0.50));
        offers.addOffer(ValidItems.LIME.name(), new Offer(3, 0.30));

        List<Item> itemList = Arrays.stream(args).map(itemName -> new Item(ValidItems.valueOf(itemName).name(), updatedItemPriceMap.get(ValidItems.valueOf(itemName).name()))).collect(Collectors.toList());

        ShoppingCart shoppingCart = new ShoppingCart();
        itemList.forEach(shoppingCart::addItem);

        double cartPrice = ShoppingCartCalculatorUtil.calculateCartPrice(shoppingCart);
        shoppingCart.viewItems();

        System.out.println("total cart price = " + cartPrice);
    }

}
