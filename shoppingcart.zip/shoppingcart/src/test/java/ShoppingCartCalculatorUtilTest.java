import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;


class ShoppingCartCalculatorUtilTest {
    static Map<String, Double> updatedItemPriceMap = new HashMap<>();
    static Offers offers;

    @org.junit.jupiter.api.BeforeAll
    static void setUp() {

        updatedItemPriceMap.put(ValidItems.APPLE.name(), 0.35);
        updatedItemPriceMap.put(ValidItems.BANANA.name(), 0.20);
        updatedItemPriceMap.put(ValidItems.MELON.name(), 0.50);
        updatedItemPriceMap.put(ValidItems.LIME.name(), 0.15);

        offers = Offers.getOffersInstance();
        offers.addOffer(ValidItems.MELON.name(), new Offer(2, 0.50));
        offers.addOffer(ValidItems.LIME.name(), new Offer(3, 0.30));

    }

    @Test
    public void calculateCartPriceWithoutOffer() {
        String[] args = {"BANANA", "APPLE", "MELON", "LIME"};
        double expectedCartPrice = 1.2;
        List<Item> itemList = Arrays.stream(args).map(itemName -> new Item(ValidItems.valueOf(itemName).name(), updatedItemPriceMap.get(ValidItems.valueOf(itemName).name()))).collect(Collectors.toList());
        ShoppingCart shoppingCart = new ShoppingCart();
        itemList.forEach(shoppingCart::addItem);

        double cartPrice = ShoppingCartCalculatorUtil.calculateCartPrice(shoppingCart);
        shoppingCart.viewItems();
        assertEquals(cartPrice, expectedCartPrice);

    }

    @Test
    public void calculateCartPriceWithOffer() {
        String[] args = {"BANANA", "APPLE", "MELON", "MELON", "LIME", "LIME", "LIME"};
        double expectedCartPrice = 1.35;
        List<Item> itemList = Arrays.stream(args).map(itemName -> new Item(ValidItems.valueOf(itemName).name(), updatedItemPriceMap.get(ValidItems.valueOf(itemName).name()))).collect(Collectors.toList());
        ShoppingCart shoppingCart = new ShoppingCart();
        itemList.forEach(shoppingCart::addItem);

        double cartPrice = ShoppingCartCalculatorUtil.calculateCartPrice(shoppingCart);
        cartPrice = Math.round(cartPrice * 100.0) / 100.0;
        shoppingCart.viewItems();
        assertEquals(cartPrice, expectedCartPrice);

    }

    @Test
    public void calculateCartPriceWithOfferForUnevenItems() {
        String[] args = {"BANANA", "APPLE", "MELON", "MELON", "MELON", "LIME", "LIME", "LIME", "LIME", "LIME"};
        double expectedCartPrice = 2.15;
        List<Item> itemList = Arrays.stream(args).map(itemName -> new Item(ValidItems.valueOf(itemName).name(), updatedItemPriceMap.get(ValidItems.valueOf(itemName).name()))).collect(Collectors.toList());
        ShoppingCart shoppingCart = new ShoppingCart();
        itemList.forEach(shoppingCart::addItem);

        double cartPrice = ShoppingCartCalculatorUtil.calculateCartPrice(shoppingCart);
        cartPrice = Math.round(cartPrice * 100.0) / 100.0;
        shoppingCart.viewItems();
        assertEquals(cartPrice, expectedCartPrice);

    }
}